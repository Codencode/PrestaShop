<?php

class Ps_Test_AdminbarFirstModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $this->context->smarty->assign('message', 'PS Test Admin Bar first front controller');
        $this->setTemplate('module:ps_test_adminbar/views/templates/front/first.tpl');
    }
}
