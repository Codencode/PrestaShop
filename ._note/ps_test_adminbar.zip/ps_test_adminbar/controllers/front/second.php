<?php

class Ps_Test_AdminbarSecondModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $this->context->smarty->assign('message', 'PS Test Admin Bar second front controller');
        $this->setTemplate('module:ps_test_adminbar/views/templates/front/second.tpl');
    }
}
