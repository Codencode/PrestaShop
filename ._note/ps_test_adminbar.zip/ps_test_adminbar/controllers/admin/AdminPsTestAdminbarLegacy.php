<?php

class AdminPsTestAdminbarLegacyController extends ModuleAdminController
{
    public function initContent()
    {
        parent::initContent();

        $this->setTemplate('../../../../modules/' . $this->module->name . '/views/templates/admin/page.tpl');
    }
}
