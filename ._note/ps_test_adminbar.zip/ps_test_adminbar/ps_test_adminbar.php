<?php

use PrestaShopBundle\Entity\Repository\TabRepository;

require_once('vendor/autoload.php');

class Ps_Test_Adminbar extends Module 
{
    public function __construct()
    {
        $this->name = 'ps_test_adminbar';
        $this->author = '';
        $this->version = '1.0.0';
        $this->need_instance = 0;
        $this->controllers = [
            'first',
            'second',
        ];

        parent::__construct();

        $this->displayName = 'ps_test_adminbar';
        $this->description = 'ps_test_adminbar';
    }

    public function install()
    {
        return parent::install()
            && $this->registerHook('actionAdminBarGetActions')
            && $this->installAdminTabs();
    }

    public function uninstall()
    {
        return $this->uninstallAdminTabs()
            && parent::uninstall();
    }

    private function installAdminTabs()
    {
        foreach (['AdminPsTestAdminbarLegacy', 'AdminPsTestAdminbarSymfony'] as $controllerName) {
            $tab = new Tab();
            $tab->class_name = $controllerName;
            $tab->module = $this->name;
            $tab->id_parent = -1;
            $tab->name = [];
            foreach (Language::getLanguages(true) as $language) {
                $tab->name[$language['id_lang']] = $this->displayName;
            }

            if (!$tab->add()) {
                return false;
            }
        }

        return true;
    }

    private function uninstallAdminTabs()
    {
        /** @var TabRepository $tabRepository */
        $tabRepository = $this->get('prestashop.core.admin.tab.repository');

        foreach (['AdminPsTestAdminbarLegacy', 'AdminPsTestAdminbarSymfony'] as $controllerName) {
            $tabId = $tabRepository->findOneIdByClassName($controllerName);

            if ($tabId !== null && !(new \Tab($tabId))->delete()) {
                return false;
            }
        }

        return true;
    }

    public function getContent()
    {
        $links = [
            'Front controller 1' => $this->context->link->getModuleLink($this->name, 'first'),
            'Front controller 2' => $this->context->link->getModuleLink($this->name, 'second'),
            'Admin legacy controller' => $this->context->link->getAdminLink('AdminPsTestAdminbarLegacy'),
            'Admin Symfony controller' => $this->context->link->getAdminLink('AdminPsTestAdminbarSymfony'),
        ];

        $content = '<ul>';
        foreach ($links as $label => $url) {
            $content .= sprintf(
                '<li><a href="%s">%s</a></li>',
                Tools::safeOutput($url),
                Tools::safeOutput($label)
            );
        }

        return $content . '</ul>';
    }

    public function hookActionAdminBarGetActions($params)
    {// TODO <cnc> ===== Front admin bar ===== - ESTENSIONE PER MODULI - Ps_Test_Adminbar::hookActionAdminBarGetActions()
        if (($params['ownerModule'] ?? null) !== $this->name) {
            return [];
        }

        $controller = $params['controller'] ?? null;

        if ($controller === 'first') {
            return [
                new \PrestaShop\PrestaShop\Adapter\AdminBar\AdminBarAction(
                    'ps_test_adminbar.open_legacy',
                    $this->getTranslator()->trans('Open admin legacy controller'),
                    [],
                    '/ps-test-adminbar/legacy'
                ),
            ];
        }

        if ($controller !== 'second') {
            return [];
        }

        return [
            new \PrestaShop\PrestaShop\Adapter\AdminBar\AdminBarAction(
                'ps_test_adminbar.open_symfony',
                $this->getTranslator()->trans('Open admin Symfony controller'),
                [],
                '/ps-test-adminbar/symfony'
            ),
        ];
    }
}
