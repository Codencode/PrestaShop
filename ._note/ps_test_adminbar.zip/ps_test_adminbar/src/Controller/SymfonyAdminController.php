<?php

declare(strict_types=1);

namespace PrestaShop\Module\PsTestAdminbar\Controller;

use PrestaShop\PrestaShop\Adapter\LegacyContext;
use PrestaShopBundle\Controller\Admin\PrestaShopAdminController;
use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Response;

final class SymfonyAdminController extends PrestaShopAdminController
{
    #[AdminSecurity("is_granted('read', 'AdminPsTestAdminbarLegacy')")]
    public function legacyAction(LegacyContext $legacyContext): RedirectResponse
    {
        return $this->redirect(
            $legacyContext->getContext()->link->getAdminLink('AdminPsTestAdminbarLegacy')
        );
    }

    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function indexAction(): Response
    {
        return $this->render('@Modules/ps_test_adminbar/views/templates/admin/symfony.html.twig');
    }
}
