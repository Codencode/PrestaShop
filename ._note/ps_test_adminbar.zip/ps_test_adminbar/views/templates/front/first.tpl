{extends file=$layout}

{block name='content'}
  <p>{$message}</p>
{/block}
